you NEED Version of Bledner 4.2 Or More, and you NEED To Be Good at Blender Because This Rig Is Not For Begginers

https://download.blender.org/release/Blender4.2/blender-4.2.4-windows-x64.msi

You dont need to credit me for the rig

Made By Fuldxx